<?php
	$config = array( 
	"keyid" => "14dacb19dc834446a6e7468f5306a7b4", 
	"xl" => "music",
	"jq" => "close",
	"mb" => "open",
	"user_id" => "1922268970",
	"user_psd" => "1922268970",
);