<?php
$config = array(
	"api" => "1",
    "w" => "136",
    "h" => "136",
    "c" => "#000000",
    "b" => "#FFFFFF",
    "ssl" => "1"
);