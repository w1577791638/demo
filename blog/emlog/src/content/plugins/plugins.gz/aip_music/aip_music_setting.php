<?php
/**
 * Plugin Name: 音乐播放器
 * Version: 2.0
 * Plugin URL: https://www.toubiec.cn/
 * Description: EMLOG播放器插件 如需使用插件 请前往xiani.toubiec.cn获取keyid！
 * Author: 苏晓晴
 * Author Email: 3074193836@qq.com
 * Author URL: https://www.toubiec.cn/
 */

!defined('EMLOG_ROOT') && exit('access deined!');
function plugin_setting_view(){
	include(EMLOG_ROOT.'/content/plugins/aip_music/aip_music_config.php');
	?>
<link href="/content/plugins/aip_music/style/style.css?ver=2.0" type="text/css" rel="stylesheet" />
	<div class="com-hd">
		<b>播放器设置</b>
		<?php
		if(isset($_GET['setting'])){
			echo "<span class='actived'>设置保存成功! </span>";
		} else {
			echo "<span class='warning'>点击保存后请耐心等候,完成解析将自动跳转! </span>";
		}
		?>
	</div>
	<form action="./plugin.php?plugin=aip_music&action=setting" method="post">
		<table class="tb-set">
			<tr>
				<td align="right"><b>线路切换：</b><br />(当播放器CDN访问异常时请切换，一般主站即可)</td>
				<td><span class="sel"><select name="xl"><option value="xiani" <?php if($config["xl"]=="xiani") echo "selected"; ?>>主线</option><option value="music" <?php if($config["xl"]=="music") echo "selected"; ?>>一线</option><option value="home" <?php if($config["xl"]=="home") echo "selected"; ?>>备用</option></select></span></td>
			</tr>
			<tr>
				<td align="right" width="40%"><b>播放器key：</b><br />(如果没有keyid可以前往<a href="https://xiani.toubiec.cn" target="_blank">xiani.toubiec.cn</a>获取！)</td>
				<td><input type="text" class="txt" name="keyid" value="<?php echo $config["keyid"];?>" /></td>
			</tr>
			<tr>
				<td align="right"><b>加载jquery：</b><br />(没有jquery库时请打开，JS冲突请关闭)</td>
				<td><span class="sel"><select name="jq"><option value="open" <?php if($config["jq"]=="open") echo "selected"; ?>>开启</option><option value="close" <?php if($config["jq"]=="close") echo "selected"; ?>>关闭</option></select></span></td>
			</tr>
			<tr>
				<td align="right"><b>移动端加载：</b><br />(开启后将在手机，iPad等移动设备加载播放器)</td>
				<td><span class="sel"><select name="mb"><option value="open" <?php if($config["mb"]=="open") echo "selected"; ?>>开启</option><option value="close" <?php if($config["mb"]=="close") echo "selected"; ?>>关闭</option></select></span></td>
			</tr>
			<tr>
				<td align="right"><b>用户名：</b><br />(填写歌单后台登陆账号，用于识别用户)</td>
				<td><input type="text" class="txt" name="user_id" value="<?php echo $config["user_id"]; ?>" /></td>
			</tr>
			<tr>
				<td align="right"><b>密码：</b><br />(填写歌单后台登陆密码，仅后台显示用于备忘)</td>
				<td><input type="text" class="txt" name="user_psd" value="<?php echo $config["user_psd"]; ?>" /></td>
			</tr>
			<tr>
				<td align="right"><b>后台地址：</b><br />(播放器歌单后台管理地址)</td>
				<td><b>播放器后台：<a href="https://xiani.toubiec.cn" target="_blank">https://xiani.toubiec.cn</a></b></td>
			</tr>
			<tr>
				<td align="right"><b>按钮：</b></td>
				<td align="left"><button class="btn" type="submit">点击保存</button></td>
			</tr>   
		</table>
	</form>
<script>
$('#aip_music').addClass('sidebarsubmenu1');
</script>
	<?php
}

function plugin_setting(){
	require_once 'aip_music_config.php';
	$xl = $_POST["xl"]==""?"player":$_POST["xl"];
	$jq = $_POST["jq"]==""?"open":$_POST["jq"];
	$mb = $_POST["mb"]==""?"open":$_POST["mb"];
	$user_id = $_POST["user_id"]==""?"suxiaoq":$_POST["user_id"];
	$user_psd = $_POST["user_psd"]==""?"asd123456":$_POST["user_psd"];
	$newConfig = '<?php
	$config = array( 
	"keyid" => "'.$_POST['keyid'].'", 
	"xl" => "'.$xl.'",
	"jq" => "'.$jq.'",
	"mb" => "'.$mb.'",
	"user_id" => "'.str_replace(array("\r\n", "\r", " ", "\n"), "", $user_id).'",
	"user_psd" => "'.str_replace(array("\r\n", "\r", " ", "\n"), "", $user_psd).'",
);';
	@file_put_contents(EMLOG_ROOT.'/content/plugins/aip_music/aip_music_config.php', $newConfig);
}
?>