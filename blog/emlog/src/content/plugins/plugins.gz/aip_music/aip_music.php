<?php
/**
 * Plugin Name: 音乐播放器
 * Version: 2.2
 * Plugin URL: https://www.toubiec.cn/
 * Description: EMLOG播放器插件 如需使用插件 请前往xiani.toubiec.cn获取keyid！
 * Author: 苏晓晴
 * Author Email: 3074193836@qq.com
 * Author URL: https://www.toubiec.cn/
 */

!defined('EMLOG_ROOT') && exit('access deined!');
function aip_music_list(){
require_once 'aip_music_config.php';
if($config["jq"]=="open"){
	echo '<script type="text/javascript" src="//lib.baomitu.com/jquery/1.9.1/jquery.min.js"></script>';
}
if($config["mb"]=="open"){
	echo '<script id="ilt" src="https://' . $config["xl"] . '.toubiec.cn/player/js/music.js" key="' . $config["keyid"] . '" m="1"></script>'."\n";
}else{
	echo '<script id="ilt" src="https://' . $config["xl"] . '.toubiec.cn/player/js/music.js" key="' . $config["keyid"] . '"></script>'."\n";
}
?>
<?php
}
function aip_music_menu() {
  echo '<div class="sidebarsubmenu" id="music"><a href="./plugin.php?plugin=aip_music">音乐播放器</a></div>';
}
addAction('index_footer', 'aip_music_list');
addAction('adm_sidebar_ext', 'aip_music_menu');