<?php
!defined('EMLOG_ROOT') && exit('access deined!');
function plugin_setting_view() {
	include 'Articleewm_config.php';
?>
<script type="text/javascript">
$("#articleewm").addClass('active');
setTimeout(hideActived,2600);
</script>
<?php if(isset($_GET['setting'])):?>
<div class="actived alert alert-success alert-dismissable">
<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
设置成功
</div>
<?php endif;?>

  <div class="des" style="margin: 5px 0; width: 100%;background-color: #FFFFE5;padding: 5px 10px;border: 1px #CCCCCC solid;clear: both;border-radius: 4px;">请选择二维码接口<br/>如有问题联系<a href="http://www.youngxj.cn">杨小杰博客</a></div>
<div class="row">
<div class="col-lg-12">
<div class="panel panel-default card-view">
<div class="panel-body"> 
<form action="plugin.php?plugin=Articleewm&action=setting" method="post">
<div class="form-group form-inline">
    <label>
    二维码渠道： </label>
  	<input type="radio" name="api" value="1" <?php if ($config["api"] == 1) { echo 'checked'; } ?>>本地qrcode.js
    <input type="radio" name="api" value="0" <?php if ($config["api"] != 1) { echo 'checked'; } ?>>草料api
    <div class="qrcode" style="<?php if ($config["api"] == 0) { echo 'display:none;'; } ?>">
</div>
<div class="form-group form-inline">
    <label>
    二维码高度：</label> <input class="form-control" type="text" name="w" value='<?php echo $config["w"];?>'>
</div>
<div class="form-group form-inline">
    <label>二维码宽度：</label> <input class="form-control" type="text" name="h" value='<?php echo $config["h"];?>'>
</div>
<div class="form-group form-inline">
    <label>二维码颜色：</label> <input class="form-control" type="text" name="c" value='<?php echo $config["c"];?>'>
</div>
<div class="form-group form-inline">
    <label>二维码背景：</label> <input class="form-control" type="text" name="b" value='<?php echo $config["b"];?>'>
    </div>
<div class="form-group form-inline">
    <label> ssl是否开启： </label>
  	<input type="radio" name="ssl" value="1" <?php if ($config["ssl"] == 1) { echo 'checked'; } ?>>是
    <input type="radio" name="ssl" value="0" <?php if ($config["ssl"] != 1) { echo 'checked'; } ?>>否
</div>
<div class="form-group">
<input type="submit" class="btn btn-success"value="保存设置"  class="button"/>
  	</div>
</form>
</div> </div> </div> </div>
<?php
}

function plugin_setting() {
	$newConfig = '<?php
$config = array(
	"api" => "'.$_POST["api"].'",
    "w" => "'.$_POST["w"].'",
    "h" => "'.$_POST["h"].'",
    "c" => "'.$_POST["c"].'",
    "b" => "'.$_POST["b"].'",
    "ssl" => "'.$_POST["ssl"].'"
);';
	@file_put_contents(EMLOG_ROOT.'/content/plugins/Articleewm/Articleewm_config.php', $newConfig);
}
?>
