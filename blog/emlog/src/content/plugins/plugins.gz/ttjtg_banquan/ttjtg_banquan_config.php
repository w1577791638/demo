<?php
$fz_kaiguan = '0';
$bk_yanse = '#000';
$zt_yanse = '#FFFFFF';
$mingcheng = '木木博客';
?>